package com.shoppers.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Admin {
    private int a_Id;
    private String a_name;
    private String a_pwd;
}
