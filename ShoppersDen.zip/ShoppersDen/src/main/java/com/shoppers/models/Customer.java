package com.shoppers.models;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Customer {
    private String address;
    private String email;
    private int userId;
    private String name;
    private String pwd;
    private String sec_ans;
    private long mobNo;
    private Cart cart;
    private String sec_q;
}
