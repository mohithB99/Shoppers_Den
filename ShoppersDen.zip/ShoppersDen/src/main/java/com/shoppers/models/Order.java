package com.shoppers.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Order {
    private int orderId;
    private LocalDate orderDate;
    private int customer_id;
    private PaymentMode paymentMode;
    private int totalPayment;
    private String status;
}
