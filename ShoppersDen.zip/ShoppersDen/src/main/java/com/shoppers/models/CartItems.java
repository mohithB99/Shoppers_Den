package com.shoppers.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class CartItems {
    private Cart cart;
    private Product product;
    private LocalDate dateAdded;
    private int quantity;
}
