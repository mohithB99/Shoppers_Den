package com.shoppers.models;

public enum PaymentMode {
    DEBIT,CREDIT,NETBANKING,UPI,COD
}
