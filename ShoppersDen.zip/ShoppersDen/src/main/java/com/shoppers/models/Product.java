package com.shoppers.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Product {
    private LocalDate date;
//    private String img_url;
    private Category category;
    private String productDesc;
    private int productId;
    private String productName;
    private int price;
    private int quantity;
}
