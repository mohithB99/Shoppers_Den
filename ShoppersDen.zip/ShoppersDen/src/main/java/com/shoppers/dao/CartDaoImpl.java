package com.shoppers.dao;

import com.shoppers.helper.PostgresConnHelper;
import com.shoppers.models.CartItems;
import com.shoppers.models.Customer;
import com.shoppers.models.Product;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CartDaoImpl implements CartDao{
    private Connection conn;
    private PreparedStatement aPTC,dPFC,uQIC,gAPIC;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;

    public CartDaoImpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }
    @Override
    public void addProductToCart(Customer customer, Product product, int quantity) throws SQLException {
        String query=resourceBundle.getString("addProductInCart");
        aPTC=conn.prepareStatement(query);
        aPTC.setInt(1,customer.getCart().getCartId());
        aPTC.setInt(2,product.getProductId());
        aPTC.setDate(3,Date.valueOf(LocalDate.now()));
        aPTC.setInt(4,quantity);
        aPTC.executeUpdate();
    }

    @Override
    public void deleteProductFromCart(Customer customer, int productId) throws SQLException {
        int cartId=customer.getCart().getCartId();
        String deleteP=resourceBundle.getString("deleteProductFromCart");
        dPFC=conn.prepareStatement(deleteP);
        dPFC.setInt(1,productId);
        dPFC.setInt(2,cartId);
        dPFC.executeUpdate();
    }

    @Override
    public void updateQuantityInCart(Customer customer, int productId, int quantity) throws SQLException {
        int cartId=customer.getCart().getCartId();
        String updateP=resourceBundle.getString("updateQuantityInCart");
        uQIC=conn.prepareStatement(updateP);
        uQIC.setInt(1,quantity);
        uQIC.setInt(2,productId);
        uQIC.setInt(3,cartId);
        uQIC.executeUpdate();
    }

    @Override
    public List<CartItems> getAllProductsInCart(Customer customer) throws SQLException {
        int cartId  = customer.getCart().getCartId();
        List<CartItems>cartItemsList=new ArrayList<>();
        Product product=null;
        CartItems cartItems=null;
        ProductDao productDao=new ProductDaoImpl();
        String getAllP=resourceBundle.getString("getAllProductsInCart");
        gAPIC=conn.prepareStatement(getAllP);
        gAPIC.setInt(1,cartId);
        resultSet=gAPIC.executeQuery();
        while (resultSet.next())
        {
            product=productDao.getProductById(resultSet.getInt(2));
            cartItems=new CartItems();
            cartItems.setQuantity(resultSet.getInt(4));
            cartItems.setDateAdded(resultSet.getDate(3).toLocalDate());
            product.setQuantity(0);
            cartItems.setProduct(product);
            cartItems.setCart(customer.getCart());
            cartItemsList.add(cartItems);
        }
        return cartItemsList;
    }
}
