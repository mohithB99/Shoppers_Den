package com.shoppers.dao;


import com.shoppers.helper.PostgresConnHelper;
import com.shoppers.models.*;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;

public class OrderDaoImpl implements OrderDao {
    private Connection conn;
    private PreparedStatement aOrder,dCartItems,aOrderItems,cOrder,gOrderById,gAllOrders,gois;
    private Statement statement;
    private ResultSet resultSet,resultSet2;
    private ResourceBundle resourceBundle;

    public OrderDaoImpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }
    @Override
    public int addOrder(Customer customer, PaymentMode paymentMode) throws SQLException {
        String query = resourceBundle.getString("addOrderDb");

        String query2 = resourceBundle.getString("deleteCartItems");

        String query3 = resourceBundle.getString("addOrderItems");

        int cartId = customer.getCart().getCartId();

        CartDao cartDao = new CartDaoImpl();
        List<CartItems> cartItemsList = cartDao.getAllProductsInCart(customer);
        int price = 0;
        for(CartItems cartItems: cartItemsList)
        {
            price+= (cartItems.getQuantity())*(cartItems.getProduct().getPrice());
        }
        aOrder = conn.prepareStatement(query);
        int orderId = 5857 + new Random().nextInt(1000);
        aOrder.setInt(1,orderId);
        aOrder.setInt(2,customer.getUserId());
        aOrder.setDate(3,Date.valueOf(LocalDate.now()));
        aOrder.setInt(4,price);
        if(paymentMode.equals(PaymentMode.DEBIT))
        {
            aOrder.setString(5,"DEBIT");
        }
        if(paymentMode.equals(PaymentMode.CREDIT))
        {
            aOrder.setString(5,"CREDIT");
        }
        if(paymentMode.equals(PaymentMode.UPI))
        {
            aOrder.setString(5,"UPI");
        }
        if(paymentMode.equals(PaymentMode.NETBANKING))
        {
            aOrder.setString(5,"NETBANKING");
        }
        if(paymentMode.equals(PaymentMode.COD))
        {
            aOrder.setString(5,"COD");
        }
        aOrder.setString(6,"Ordered");
        aOrder.executeUpdate();

        dCartItems = conn.prepareStatement(query2);
        dCartItems.setInt(1,cartId);
        dCartItems.executeUpdate();

        for(CartItems cartItems : cartItemsList)
        {
            aOrderItems = conn.prepareStatement(query3);
            aOrderItems.setInt(1,orderId);
            aOrderItems.setInt(2,cartItems.getProduct().getProductId());
            aOrderItems.setInt(3,cartItems.getQuantity());
            aOrderItems.executeUpdate();
        }
        return orderId;

    }

    @Override
    public void cancelOrder(int order_id) throws SQLException {
        String query = resourceBundle.getString("cancelOrder");

        cOrder = conn.prepareStatement(query);
        cOrder.setInt(1,order_id);
        cOrder.executeUpdate();
    }

    @Override
    public Order getOrderById(int order_id) throws SQLException {
        String query = resourceBundle.getString("getOrderById");

        Order order = new Order();

        gOrderById = conn.prepareStatement(query);

        gOrderById.setInt(1,order_id);

        resultSet2 = gOrderById.executeQuery();
        while(resultSet2.next())
        {
            order.setOrderId(resultSet2.getInt(1));
            order.setCustomer_id(resultSet2.getInt(2));
            order.setOrderDate(resultSet2.getDate(3).toLocalDate());
            order.setTotalPayment(resultSet2.getInt(4));
            String paymentMode = resultSet2.getString(5);
            if(paymentMode.equals("DEBIT"))
            {
                order.setPaymentMode(PaymentMode.DEBIT);
            }
            if(paymentMode.equals("CREDIT"))
            {
                order.setPaymentMode(PaymentMode.CREDIT);
            }
            if(paymentMode.equals("NETBANKING"))
            {
                order.setPaymentMode(PaymentMode.NETBANKING);
            }
            if(paymentMode.equals("UPI"))
            {
                order.setPaymentMode(PaymentMode.UPI);
            }
            if(paymentMode.equals("COD"))
            {
                order.setPaymentMode(PaymentMode.COD);
            }
            order.setStatus(resultSet2.getString(6));
        }
        return order;
    }

    @Override
    public List<Order> getAllOrdersOfCustomer(int customer_id) throws SQLException {
        String query = resourceBundle.getString("getAllOrdersOfCustomer");

        gAllOrders = conn.prepareStatement(query);
        gAllOrders.setInt(1,customer_id);

        List<Order> orderList = new ArrayList<Order>();
        Order order = null;

        resultSet2 = gAllOrders.executeQuery();
        while(resultSet2.next())
        {
            order = new Order();
            order.setOrderId(resultSet2.getInt(1));
            order.setCustomer_id(resultSet2.getInt(2));
            order.setOrderDate(resultSet2.getDate(3).toLocalDate());
            order.setTotalPayment(resultSet2.getInt(4));
            String paymentMode = resultSet2.getString(5);
            if(paymentMode.equals("DEBIT"))
            {
                order.setPaymentMode(PaymentMode.DEBIT);
            }
            if(paymentMode.equals("CREDIT"))
            {
                order.setPaymentMode(PaymentMode.CREDIT);
            }
            if(paymentMode.equals("NETBANKING"))
            {
                order.setPaymentMode(PaymentMode.NETBANKING);
            }
            if(paymentMode.equals("UPI"))
            {
                order.setPaymentMode(PaymentMode.UPI);
            }
            if(paymentMode.equals("COD"))
            {
                order.setPaymentMode(PaymentMode.COD);
            }
            order.setStatus(resultSet2.getString(6));
            orderList.add(order);
        }
        return orderList;
    }
    public List<Product> showOrderItems(int order_id) throws SQLException {
        String query3=resourceBundle.getString("getProductsInOrder");
        List<Product>productList=new ArrayList<Product>();
        gois=conn.prepareStatement(query3);
        gois.setInt(1,order_id);
        ProductDao productDao=new ProductDaoImpl();
        resultSet=gois.executeQuery();
        while(resultSet.next())
        {
            int productId=resultSet.getInt(1);
            int qty=resultSet.getInt(2);
            Product product=productDao.getProductById(productId);
            product.setQuantity(qty);
            productList.add(product);
        }
        return productList;
    }
}
