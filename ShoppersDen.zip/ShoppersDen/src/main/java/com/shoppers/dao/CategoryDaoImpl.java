package com.shoppers.dao;

import com.shoppers.helper.PostgresConnHelper;
import com.shoppers.models.Category;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CategoryDaoImpl implements CategoryDao {
    private ResourceBundle resourceBundle;
    private PreparedStatement aCat,dCat,uCat;
    private Statement statement,statement2;
    private Connection conn;

    private ResultSet resultSet;
    public CategoryDaoImpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle= ResourceBundle.getBundle("db");
    }


    @Override
    public void addCategory(Category category) throws SQLException {
        String query = resourceBundle.getString("addCategory");
        aCat = conn.prepareStatement(query);
        aCat.setInt(1,category.getCategoryId());
        aCat.setString(2,category.getCategoryName());
        aCat.executeUpdate();
    }

    @Override
    public List<? extends Category> getAllCategories() throws SQLException {
        conn=PostgresConnHelper.getConnection();

        List<Category> categoryList=null;
        Category category=null;
        categoryList=new ArrayList<Category>();
        String query=resourceBundle.getString("getAllCategory");
        statement=conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next()){
            category=new Category();
            category.setCategoryId(resultSet.getInt(1));
            category.setCategoryName(resultSet.getString(2));

            categoryList.add(category);
        }
        return categoryList;
    }

    @Override
    public Category getCategoryById(int categoryId) throws SQLException {
        Category category = new Category();
        String query = resourceBundle.getString("getCategory");
        statement2 = conn.createStatement();
        resultSet=statement2.executeQuery(query+categoryId);
        while(resultSet.next())
        {
            category.setCategoryId(resultSet.getInt(1));
            category.setCategoryName(resultSet.getString(2));
        }
        return category;

    }

    @Override
    public void deleteCategory(int categoryId) throws SQLException {
        String query = resourceBundle.getString("deleteCategory");
        dCat = conn.prepareStatement(query);
        dCat.setInt(1,categoryId);
        dCat.executeUpdate();
    }

    @Override
    public void updateCategoryName(int categoryId, String name) throws SQLException {
        String query = resourceBundle.getString("updateCategoryName");
        uCat = conn.prepareStatement(query);
        uCat.setString(1,name);
        uCat.setInt(2,categoryId);
        uCat.executeUpdate();
    }
}
