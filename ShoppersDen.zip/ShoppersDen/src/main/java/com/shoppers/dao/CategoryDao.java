package com.shoppers.dao;

import com.shoppers.models.Category;

import java.sql.SQLException;
import java.util.List;

public interface CategoryDao {
    void addCategory(Category category) throws SQLException;
    List<? extends Category> getAllCategories() throws SQLException;
    Category getCategoryById(int categoryId) throws SQLException;
    void deleteCategory(int categoryId) throws SQLException;
    void updateCategoryName(int categoryId,String name) throws SQLException;
}
