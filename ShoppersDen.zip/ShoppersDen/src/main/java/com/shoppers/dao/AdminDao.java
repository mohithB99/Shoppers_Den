package com.shoppers.dao;

import com.shoppers.models.Admin;
import com.shoppers.models.Customer;

import java.sql.SQLException;
import java.util.List;

public interface AdminDao {
    List<Customer> getAllUsers();
    public void addCustomer(Customer customer) throws SQLException;
    public void addAdmin(Admin admin) throws SQLException;
    public void updateAdminName(int a_Id,String name) throws SQLException;
    public void deleteAdmin(int a_id) throws SQLException;
    public void updateCustomerName(int c_id,String name) throws SQLException;
    public void deleteCustomer(int c_id) throws SQLException;
    public Customer getCustomer(int c_id) throws SQLException;
    public Admin getAdmin(int admin_id) throws SQLException;
}
