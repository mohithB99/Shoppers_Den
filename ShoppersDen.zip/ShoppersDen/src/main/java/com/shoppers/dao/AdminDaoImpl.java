package com.shoppers.dao;

import com.shoppers.helper.PostgresConnHelper;
import com.shoppers.models.Admin;
import com.shoppers.models.Cart;
import com.shoppers.models.Customer;

import java.sql.*;
import java.util.List;
import java.util.ResourceBundle;

public class AdminDaoImpl implements  AdminDao{
    private Connection conn;
    private PreparedStatement pu,pc,pUAN,dA,dC,pUCN,pCI;
    private ResourceBundle resourceBundle;
    private Statement statement;
    private ResultSet resultSet,resultSet2;

    public AdminDaoImpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public List<Customer> getAllUsers() {
        return null;
    }

    @Override
    public void addCustomer(Customer customer) throws SQLException {
        String adduser=resourceBundle.getString("addCustomer");
        try {
            pc = conn.prepareStatement(adduser);
            pc.setInt(1, customer.getUserId());
            pc.setString(2,customer.getAddress());
            pc.setString(3, customer.getEmail());
            pc.setString(4, customer.getName());
            pc.setString(5,customer.getPwd());
            pc.setLong(6,customer.getMobNo());
            pc.setString(7,customer.getSec_ans());
            pc.setString(8,customer.getSec_q());
            pc.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void addAdmin(Admin admin) throws SQLException {
        String adduser=resourceBundle.getString("addAdmin");
        try {
            pu = conn.prepareStatement(adduser);
            pu.setInt(1, admin.getA_Id());
            pu.setString(2, admin.getA_name());
            pu.setString(3, admin.getA_pwd());
            pu.executeUpdate();

        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());

        }
    }

    @Override
    public void updateAdminName(int a_Id,String name) throws SQLException {
        String query = resourceBundle.getString("updateAdminName");
        pUAN = conn.prepareStatement(query);
        pUAN.setString(1,name);
        pUAN.setInt(2,a_Id);
        pUAN.executeUpdate();

    }

    @Override
    public void deleteAdmin(int a_Id) throws SQLException {
        String query = resourceBundle.getString("deleteAdmin");
        dA = conn.prepareStatement(query);
        dA.setInt(1,a_Id);
        dA.executeUpdate();

    }

    @Override
    public void updateCustomerName(int c_id, String name) throws SQLException {
        String query = resourceBundle.getString("updateCustomerName");

        pUCN = conn.prepareStatement(query);
        pUCN.setString(1,name);
        pUCN.setInt(2,c_id);
        pUCN.executeUpdate();
    }

    @Override
    public void deleteCustomer(int c_id) throws SQLException {
        String query = resourceBundle.getString("deleteCustomer");
        dC = conn.prepareStatement(query);
        dC.setInt(1,c_id);
        dC.executeUpdate();
    }

    @Override
    public Customer getCustomer(int c_id) throws SQLException {
        Customer customer = new Customer();
        String query = resourceBundle.getString("getCus");
        statement = conn.createStatement();
        resultSet = statement.executeQuery(query+c_id);
        //System.out.println(resultSet);
        while(resultSet.next())
        {
            customer.setUserId(resultSet.getInt(1));
            customer.setAddress(resultSet.getString(2));
            customer.setEmail(resultSet.getString(3));
            customer.setName(resultSet.getString(4));
            //customer.setPwd(resultSet.getString(5));
            customer.setMobNo(resultSet.getLong(5));
            //customer.setSec_ans(resultSet.getString(7));
            //customer.setSec_q(resultSet.getString(8));
            String query2 = resourceBundle.getString("getCartIdByUserId");
            pCI=conn.prepareStatement(query2);
            pCI.setInt(1,resultSet.getInt(1));
            resultSet2=pCI.executeQuery();
            Cart cart = new Cart();
            while (resultSet2.next())
            {
                cart.setCartId(resultSet2.getInt(1));
                cart.setCustomerId(resultSet.getInt(1));
            }
            customer.setCart(cart);
        }
        return customer;
    }

    public Admin getAdmin(int admin_id) throws SQLException {
        Admin admin = new Admin();
        String query = resourceBundle.getString("getAdmin");
        statement = conn.createStatement();
        resultSet = statement.executeQuery(query+admin_id);
        //System.out.println(resultSet);
        while(resultSet.next())
        {
            admin.setA_Id(resultSet.getInt(1));
            admin.setA_name(resultSet.getString(2));
            admin.setA_pwd(resultSet.getString(3));
        }
        return admin;
    }




}
