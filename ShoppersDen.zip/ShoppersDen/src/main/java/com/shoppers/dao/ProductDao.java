package com.shoppers.dao;

import com.shoppers.models.Product;

import java.sql.SQLException;
import java.util.List;

public interface ProductDao {
    void addProduct(Product product) throws SQLException;
    void updateProductQuantity(int productId,int quantity) throws SQLException;
    void deleteProduct(int productId) throws SQLException;
    List<Product> getAllProducts() throws SQLException;
    Product getProductById(int p_id) throws SQLException;
}
