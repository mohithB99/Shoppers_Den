package com.shoppers.dao;

import com.shoppers.models.Customer;
import com.shoppers.models.Order;
import com.shoppers.models.PaymentMode;
import com.shoppers.models.Product;

import java.sql.SQLException;
import java.util.List;

public interface OrderDao {
    int addOrder(Customer customer, PaymentMode paymentMode) throws SQLException;
    void cancelOrder(int order_id) throws SQLException;
    Order getOrderById(int order_id) throws SQLException;
    List<Order> getAllOrdersOfCustomer(int customer_id) throws SQLException;
    public List<Product> showOrderItems(int order_id) throws SQLException;
}
