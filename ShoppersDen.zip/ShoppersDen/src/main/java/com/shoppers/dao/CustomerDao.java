package com.shoppers.dao;

import com.shoppers.models.Admin;
import com.shoppers.models.Customer;

import java.sql.SQLException;

public interface CustomerDao {
    public void addCustomer(Customer customer) throws SQLException;
    public void updateCustomerName(int c_id,String name) throws SQLException;
    public void deleteCustomer(int c_id) throws SQLException;
}
