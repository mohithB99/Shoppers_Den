package com.shoppers.dao;

import com.shoppers.models.CartItems;
import com.shoppers.models.Customer;
import com.shoppers.models.Product;

import java.sql.SQLException;
import java.util.List;

public interface CartDao {
    public void addProductToCart(Customer customer, Product product, int quantity) throws SQLException;
    public void deleteProductFromCart(Customer customer, int productId) throws SQLException;
    public void updateQuantityInCart(Customer customer, int productId, int quantity) throws SQLException;
    public List<CartItems> getAllProductsInCart(Customer customer) throws SQLException;
}
