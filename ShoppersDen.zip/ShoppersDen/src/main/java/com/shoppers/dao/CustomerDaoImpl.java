package com.shoppers.dao;


import com.shoppers.helper.PostgresConnHelper;
import com.shoppers.models.Customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class CustomerDaoImpl implements CustomerDao {
    private Connection conn;
    private PreparedStatement pc,uc,dC,pCart,dCart;
    private ResourceBundle resourceBundle;

    public CustomerDaoImpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }
    @Override
    public void addCustomer(Customer customer) throws SQLException {
        String adduser=resourceBundle.getString("addCustomer");
        String addCart = resourceBundle.getString("addCart");
        try {
            pc = conn.prepareStatement(adduser);
            pc.setInt(1, customer.getUserId());
            pc.setString(2,customer.getAddress());
            pc.setString(3, customer.getEmail());
            pc.setString(4, customer.getName());
            pc.setString(5,customer.getPwd());
            pc.setLong(6,customer.getMobNo());
            pc.setString(7,customer.getSec_ans());
            pc.setString(8,customer.getSec_q());
            pc.executeUpdate();
            pCart = conn.prepareStatement(addCart);
            pCart.setInt(1,customer.getCart().getCartId());
            pCart.setInt(2,customer.getUserId());
            pCart.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void updateCustomerName(int c_id, String name) throws SQLException {
        String query = resourceBundle.getString("updateCustomerName");

        uc = conn.prepareStatement(query);
        uc.setString(1,name);
        uc.setInt(2,c_id);
        uc.executeUpdate();
    }

    @Override
    public void deleteCustomer(int c_id) throws SQLException {
        String query = resourceBundle.getString("deleteCustomer");
        String deleteCart = resourceBundle.getString("deleteCart");
        dCart = conn.prepareStatement(deleteCart);
        dCart.setInt(1,c_id);
        dCart.executeUpdate();
        dC = conn.prepareStatement(query);
        dC.setInt(1,c_id);
        dC.executeUpdate();
    }
}
