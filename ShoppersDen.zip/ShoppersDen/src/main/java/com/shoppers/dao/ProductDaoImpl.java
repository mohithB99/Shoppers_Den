package com.shoppers.dao;

import com.shoppers.helper.PostgresConnHelper;
import com.shoppers.models.Category;
import com.shoppers.models.Product;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class ProductDaoImpl implements ProductDao{
    private Connection conn;
    private ResourceBundle resourceBundle;
    private PreparedStatement aP,uP,dP,gPBI,gAP;
    private Statement statement;
    private ResultSet resultSet;

    public ProductDaoImpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle= ResourceBundle.getBundle("db");
    }
    @Override
    public void addProduct(Product product) throws SQLException {
        String query = resourceBundle.getString("addProduct");
        aP=conn.prepareStatement(query);
        aP.setString(1, product.getProductDesc());
        aP.setLong(2,product.getProductId());
        aP.setString(3,product.getProductName());
        aP.setInt(4,product.getPrice());
        aP.setInt(5,product.getQuantity());
        aP.setDate(6,Date.valueOf(LocalDate.now()));
        aP.setLong(7,product.getCategory().getCategoryId());
        aP.executeUpdate();
    }

    @Override
    public void updateProductQuantity(int productId,int quantity) throws SQLException {
        String query = resourceBundle.getString("updateProductQuantity");
        uP = conn.prepareStatement(query);
        uP.setInt(1,quantity);
        uP.setInt(2,productId);
        uP.executeUpdate();
    }

    @Override
    public void deleteProduct(int productId) throws SQLException {
        String query = resourceBundle.getString("deleteProduct");
        dP = conn.prepareStatement(query);
        dP.setInt(1,productId);
        dP.executeUpdate();
    }

    @Override
    public List<Product> getAllProducts() throws SQLException {
        List<Product>productList=new ArrayList<Product>();
        Product product= null;
        String query = resourceBundle.getString("getAllProduct");
        statement = conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next())
        {
            product = new Product();
            product.setProductDesc(resultSet.getString(1));
            product.setProductId(resultSet.getInt(2));
            product.setProductName(resultSet.getString(3));
            product.setPrice(resultSet.getInt(4));
            product.setQuantity(resultSet.getInt(5));
            product.setDate(resultSet.getDate(6).toLocalDate());
            CategoryDao categoryDao = new CategoryDaoImpl();
            Category category=categoryDao.getCategoryById(resultSet.getInt(7));
            product.setCategory(category);
            productList.add(product);
        }
        return productList;
    }

    @Override
    public Product getProductById(int productId) throws SQLException {
        Product product=new Product();
        String query = resourceBundle.getString("getProductById");
        gPBI=conn.prepareStatement(query);
        gPBI.setInt(1,productId);
        resultSet=gPBI.executeQuery();
        while(resultSet.next())
        {
            product.setProductDesc(resultSet.getString(1));
            product.setProductId(resultSet.getInt(2));
            product.setProductName(resultSet.getString(3));
            product.setPrice(resultSet.getInt(4));
            product.setQuantity(resultSet.getInt(5));
            product.setDate(resultSet.getDate(6).toLocalDate());
            CategoryDao categoryDao = new CategoryDaoImpl();
            Category category=categoryDao.getCategoryById(resultSet.getInt(7));
            product.setCategory(category);
        }
        return product;
    }
}
