package com.shoppers.helper;

import com.shoppers.models.*;

import java.time.LocalDate;
import java.util.Random;
import java.util.Scanner;

public class CreateObjects {
    public  Admin createAdmin()
    {
        Scanner sc = new Scanner(System.in);
        Admin user = new Admin();
        user.setA_Id(1234 + new Random().nextInt(1000));

        System.out.println("Enter name: ");
        user.setA_name(sc.nextLine());

        System.out.println("Password: ");
        user.setA_pwd(sc.nextLine());

        return user;
    }
    public Customer createCustomer()
    {
        Scanner sc = new Scanner(System.in);
        Customer user = new Customer();

        user.setUserId(9849 + new Random().nextInt(1000));

        System.out.println("Enter your Address: ");
        user.setAddress(sc.nextLine());

        System.out.println("Enter e-Mail: ");
        user.setEmail(sc.nextLine());

        System.out.println("Enter name: ");
        user.setName(sc.nextLine());

        System.out.println("Enter Mobile Number: ");
        user.setMobNo(Integer.parseInt(sc.nextLine()));

        System.out.println("Password: ");
        user.setPwd(sc.nextLine());

        System.out.println("Enter Security Question: ");
        user.setSec_q(sc.nextLine());

        System.out.println("Enter Security Ans: ");
        user.setSec_ans(sc.nextLine());

        Cart cart = new Cart();
        cart.setCartId(4587+new Random().nextInt(1000));
        cart.setCustomerId(user.getUserId());
        user.setCart(cart);
        return user;
    }
    public static Category createCategory()
    {
        Scanner sc = new Scanner(System.in);
        Category category = new Category();
        category.setCategoryId(4556 + new Random().nextInt(1000));

        System.out.println("Enter Category Name: ");
        category.setCategoryName(sc.nextLine());

        return category;
    }
    public Product createProduct()
    {
        Scanner sc = new Scanner(System.in);
        Product product=new Product();

        product.setDate(LocalDate.now());

        Category c=new Category();
        System.out.println("Enter Category ID: ");
        c.setCategoryId(Integer.parseInt(sc.nextLine()));

        System.out.println("Enter Category Name: ");
        c.setCategoryName(sc.nextLine());

        product.setCategory(c);

        System.out.println("Enter product Description: ");
        product.setProductDesc(sc.nextLine());

        System.out.println("Enter product price: ");
        product.setPrice(Integer.parseInt(sc.nextLine()));

        product.setProductId(4665+ new Random().nextInt(1000));

        System.out.println("Enter Product Name: ");
        product.setProductName(sc.nextLine());

        System.out.println("Enter Quantity in Warehouse: ");
        product.setQuantity(Integer.parseInt(sc.nextLine()));

        return product;
    }
}
