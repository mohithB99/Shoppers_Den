package com.shoppers.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class LoginAuthentication {
    private Connection conn;
    private PreparedStatement customerCheck,adminCheck;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;

    public LoginAuthentication()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }


    public boolean customerAuthentication(int customer_id,String password) throws SQLException {
        boolean loginVerify = false;
        String query = resourceBundle.getString("verifyCustomer");
        customerCheck =conn.prepareStatement(query);
        customerCheck.setInt(1,customer_id);
        resultSet = customerCheck.executeQuery();
        while(resultSet.next())
        {
            String mainPassword = resultSet.getString(1);
            if(mainPassword.equals(password))
            {
                loginVerify = true;
            }
        }
        return loginVerify;
    }
    public boolean adminAuthentication(int a_id,String password) throws SQLException {
        boolean loginVerify = false;
        String query = resourceBundle.getString("verifyAdmin");
        adminCheck =conn.prepareStatement(query);
        adminCheck.setInt(1,a_id);
        resultSet = adminCheck.executeQuery();
        while(resultSet.next())
        {
            String mainPassword = resultSet.getString(1);
            if(mainPassword.equals(password))
            {
                loginVerify = true;
            }
        }
        return loginVerify;
    }

}
