package com.shoppers.utility;

import com.shoppers.dao.*;
import com.shoppers.helper.CreateObjects;
import com.shoppers.helper.LoginAuthentication;
import com.shoppers.models.*;


import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class ShoppersApp {
    public static void main(String[] args) throws SQLException {

        Scanner sc = new Scanner(System.in);

        boolean verification = false;

        CustomerDao customerDao = new CustomerDaoImpl();
        AdminDao adminDao = new AdminDaoImpl();
        CartDao cartDao = new CartDaoImpl();
        OrderDao orderDao = new OrderDaoImpl();
        ProductDao productDao = new ProductDaoImpl();
        CategoryDao categoryDao = new CategoryDaoImpl();
        CreateObjects createObjects =new CreateObjects();
        LoginAuthentication loginAuthentication = new LoginAuthentication();

        Customer customer = null;

        loop:while(true) {
            System.out.println("Welcome to Shoppers Den");
            System.out.println("1 - Sign-In");
            System.out.println("2 - Register/Sign-Up");
            System.out.println("3 - Exit from Portal");
            int choice = Integer.parseInt(sc.nextLine());
            switch (choice) {
                case 1:
                    System.out.println("Enter your Customer ID: ");
                    int customer_id = Integer.parseInt(sc.nextLine());
                    System.out.println("Enter your Password: ");
                    String password = sc.nextLine();
                    if (loginAuthentication.customerAuthentication(customer_id, password))
                    {
                        customer = adminDao.getCustomer(customer_id);
                        verification=true;
                    }
                    else
                    {
                        System.out.println("Enter a Valid ID or Password. ");
                        continue loop;
                    }
                    break loop;
                case 2:
                    customer = createObjects.createCustomer();
                    customerDao.addCustomer(customer);
                    System.out.println("You have been successfully registered with Customer Id : " + customer.getUserId());
                    continue loop;
                case 3:
                    System.exit(0);
            }
        }
        if(verification){
            System.out.println("You have logged in with user id: " + customer.getUserId());
            System.out.println("Welcome " + customer.getName());
            shopping:
            while (true) {
                System.out.println("1 - View All Categories");
                System.out.println("2 - View All Products ");
                System.out.println("3 - Add to Cart ");
                System.out.println("4 - View Products in Cart");

                System.out.println("5 - Place Order ");


                System.out.println("6 - View Profile ");
                System.out.println("7 - Update Profile ");
                System.out.println("8 - Delete Profile");

                System.out.println("9 - Cancel Order");
                System.out.println("10 - Order History");
                System.out.println("11 - View Specific Order by Order-ID");
                System.out.println("12 - Show Order Items in particular Order.");

                System.out.println("13 - Delete product from cart");
                System.out.println("14 - Update Quantity of product in cart");
                System.out.println("15 - Logout and exit");

                System.out.println("Enter your choice: ");

                int choice = Integer.parseInt(sc.nextLine());
                switch (choice) {
                    case 1:
                        for (Category category : categoryDao.getAllCategories())
                            System.out.println(category.getCategoryName());
                        continue shopping;
                    case 2:
                        for (Product product : productDao.getAllProducts())
                            System.out.println(product.getProductId()
                                    + " " + product.getProductName()
                                    + " " + product.getPrice()
                                    + " " + product.getProductDesc());
                        continue shopping;
                    case 3:
                        System.out.println("Enter Product ID: ");
                        int productId = Integer.parseInt(sc.nextLine());
                        System.out.println("Enter quantity: ");
                        int qty = Integer.parseInt(sc.nextLine());
                        cartDao.addProductToCart(customer, productDao.getProductById(productId),qty);
                        System.out.println("Given product is successfully to your cart. ");
                        continue shopping;
                    case 4:
                        System.out.println("Your cart items ");
                        for (CartItems cartItems : cartDao.getAllProductsInCart(customer)) {
                            System.out.println(cartItems.getProduct().getProductName()
                                    + " " + cartItems.getQuantity() + " " + cartItems.getProduct().getPrice());
                        }
                        continue shopping;
                    case 5:
                        System.out.println("Placing the Order...");
                        System.out.println("Enter the mode of payment: ");
                        String paymentMode = sc.nextLine();

                        int orderId=0;
                        if(paymentMode.equals("DEBIT"))
                        {
                            orderId = orderDao.addOrder(customer,PaymentMode.DEBIT);
                        }
                        if(paymentMode.equals("CREDIT"))
                        {
                            orderId = orderDao.addOrder(customer,PaymentMode.CREDIT);
                        }
                        if(paymentMode.equals("NETBANKING"))
                        {
                            orderId = orderDao.addOrder(customer,PaymentMode.NETBANKING);
                        }
                        if(paymentMode.equals("UPI"))
                        {
                            orderId = orderDao.addOrder(customer,PaymentMode.UPI);
                        }
                        if(paymentMode.equals("COD"))
                        {
                            orderId = orderDao.addOrder(customer,PaymentMode.COD);
                        }

                        System.out.println("Your Order has been placed successfully. ");
                        System.out.println("Your order is " + orderId);
                        continue shopping;
                    case 6:
                        System.out.println("Your details are ");
                        System.out.println("Your user id is " + customer.getUserId()
                                + " " + "Your name is " + customer.getName()
                                + " " + "Your phone number is " + customer.getMobNo()
                                + " " + "Your email is " + customer.getEmail());
                        System.out.println("Your orders are ");
                        for (Order order : orderDao.getAllOrdersOfCustomer(customer.getUserId())) {
                            System.out.println("Your order id is " + order.getOrderId()
                                    + " " + "Your total amount is " + order.getTotalPayment()
                                    + " " + "Your mode is " + order.getPaymentMode());
                        }
                        continue shopping;
                    case 7:
                        System.out.println("You are in Update profile section. ");
                        System.out.println("Enter your updated name");
                        String newName = sc.nextLine();
                        customerDao.updateCustomerName(customer.getUserId(), newName);
                        System.out.println("Your name has been updated successfully. ");
                        continue shopping;
                    case 8:
                        customerDao.deleteCustomer(customer.getUserId());
                        System.out.println("Your profile is successfully deleted. ");
                        System.exit(0);
                    case 9:
                        System.out.println("Enter the ID of the Order you want to cancel: ");
                        int order_id = Integer.parseInt(sc.nextLine());
                        orderDao.cancelOrder(order_id);
                        System.out.println("Your order is canceled successfully ");
                        continue shopping;
                    case 10:
                        System.out.println("Your Orders are: ");
                        for (Order order1 : orderDao.getAllOrdersOfCustomer(customer.getUserId())) {
                            System.out.println("Your order id is " + order1.getOrderId()
                                    + " " + "Your total amount is " + order1.getTotalPayment()
                                    + " " + "Your mode is " + order1.getPaymentMode());
                        }
                        continue shopping;
                    case 11:
                        System.out.println("Enter your Order ID: ");
                        int order_id1 = Integer.parseInt(sc.nextLine());
                        Order order = orderDao.getOrderById(order_id1);
                        System.out.println(order.getOrderId() + " " + order.getTotalPayment() + " " + order.getStatus());
                        continue shopping;
                    case 12:
                        System.out.println("Enter the Order ID: ");
                        int orderid = Integer.parseInt(sc.nextLine());
                        List<Product> productList = orderDao.showOrderItems(orderid);
                        System.out.println(productList);
                        continue shopping;
                    case 13:
                        System.out.println("Enter the Product ID: ");
                        int p_id1 = Integer.parseInt(sc.nextLine());
                        cartDao.deleteProductFromCart(customer,p_id1);
                        continue shopping;
                    case 14:
                        System.out.println("Enter the Product ID: ");
                        int p_id2 = Integer.parseInt(sc.nextLine());
                        System.out.println("Enter Quantity:");
                        int qty2 = Integer.parseInt(sc.nextLine());
                        cartDao.updateQuantityInCart(customer,p_id2,qty2);
                        continue shopping;
                    case 15:
                        System.out.println("You have been successfully logged out ");
                        System.exit(0);

                    default:
                        break shopping;
                }
            }
        }
        System.out.println("Thank you for shopping with Shoppers Den");
        }
    }


   // Scanner sc = new Scanner(System.in);
    //        AdminDao adminDao = new AdminDaoImpl();
//        adminDao.addAdmin(createAdmin());
    //CustomerDao customerDao = new CustomerDaoImpl();
    //customerDao.addCustomer(createCustomer());
//        CategoryDao categoryDao = new CategoryDaoImpl();
//        categoryDao.addCategory(createCategory());
    //CreateObjects createObjects = new CreateObjects();
    //ProductDao productDao = new ProductDaoImpl();
       // productDao.addProduct(createObjects.createProduct());
//CartDao cartDao = new CartDaoImpl();
//OrderDao orderDao = new OrderDaoImpl();
//LoginAuthentication loginAuthentication = new LoginAuthentication();
//System.out.println(loginAuthentication.customerAuthentication(10417,"5678"));
//List<Order> order =orderDao.getAllOrdersOfCustomer(10417);
//System.out.println(order);
//Customer customer = adminDao.getCustomer(10417);
//orderDao.addOrder(customer,PaymentMode.DEBIT);
//orderDao.cancelOrder(6514);
//System.out.println(customer);
//Product product = productDao.getProductById(5450);


//cartDao.addProductToCart(customer,product,5);
//List<CartItems> cartItems = cartDao.getAllProductsInCart(customer);
//System.out.println(cartItems);

//cartDao.deleteProductFromCart(customer,product.getProductId());
//cartDao.updateQuantityInCart(customer,product.getProductId(),30);

//categoryDao.addCategory(createCategory());

//List<Product> product = productDao.getAllProducts();
//System.out.println(product);
//productDao.deleteProduct(5373);

//List<Category> category = (List<Category>) categoryDao.getAllCategories();
//System.out.println(category);

//Customer customer = adminDao.getCustomer(10374);
//customerDao.deleteCustomer(10442);
//System.out.println(customer);
//customerDao.addCustomer((createCustomer()));

//adminDao.addAdmin(createAdmin());
