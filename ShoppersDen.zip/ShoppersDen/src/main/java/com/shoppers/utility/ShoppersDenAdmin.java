package com.shoppers.utility;

import com.shoppers.dao.*;
import com.shoppers.helper.CreateObjects;
import com.shoppers.helper.LoginAuthentication;
import com.shoppers.models.*;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class ShoppersDenAdmin {
    public static void main(String[] args) throws SQLException {
        Scanner sc = new Scanner(System.in);

        boolean verification = false;

        CustomerDao customerDao = new CustomerDaoImpl();
        AdminDao adminDao = new AdminDaoImpl();
        CartDao cartDao = new CartDaoImpl();
        OrderDao orderDao = new OrderDaoImpl();
        ProductDao productDao = new ProductDaoImpl();
        CategoryDao categoryDao = new CategoryDaoImpl();
        CreateObjects createObjects = new CreateObjects();
        LoginAuthentication loginAuthentication = new LoginAuthentication();

        Customer customer = null;
        Admin admin = null;

        loop:
        while (true) {
            System.out.println("Welcome to Shoppers Den");
            System.out.println("1 - Sign-In");
            System.out.println("2 - Register/Sign-Up");
            System.out.println("3 - Exit from Portal");
            int choice = Integer.parseInt(sc.nextLine());
            switch (choice) {
                case 1:
                    System.out.println("Enter your Admin ID: ");
                    int admin_id = Integer.parseInt(sc.nextLine());
                    System.out.println("Enter your Password: ");
                    String password = sc.nextLine();
                    if (loginAuthentication.adminAuthentication(admin_id, password)) {
                        admin = adminDao.getAdmin(admin_id);
                        verification = true;
                    } else {
                        System.out.println("Enter a Valid ID or Password. ");
                        continue loop;
                    }
                    break loop;
                case 2:
                    admin = createObjects.createAdmin();
                    adminDao.addAdmin(admin);
                    System.out.println("You have been successfully registered with Admin Id : " + admin.getA_Id());
                    continue loop;
                case 3:
                    System.exit(0);
            }
        }
        if (verification) {
            System.out.println("You have logged in as Admin with Admin ID: " + admin.getA_Id());
            System.out.println("Welcome " + admin.getA_name());
            ADMIN:while(true) {

                System.out.println("1 - Get a particular Customer ");
                System.out.println("2 - Delete customer ");

                System.out.println("3 - Add Category ");
                System.out.println("4 - Delete Category ");
                System.out.println("5 - Update Category Name");
                System.out.println("6 - Get Category By ID ");
                System.out.println("7 - Get All Categories ");

                System.out.println("8 - Add Product ");
                System.out.println("9 - Update Product Name ");
                System.out.println("10 - Delete Product ");
                System.out.println("11 - Get all Products ");
                System.out.println("12 - Get a particular product ");

                System.out.println("13 - Order History");
                System.out.println("14 - All Orders of User ");
                System.out.println("15 - Cancel Order by Order ID");

                System.out.println("16 - View Profile ");
                System.out.println("17 - Update Profile ");
                System.out.println("18 - Delete Admin Profile");

                System.out.println("19 - View Ordered Items by Order ID ");

                System.out.println("20 - Log out and exit ");
                System.out.println("Enter your choice ");

                int choice = Integer.parseInt(sc.nextLine());
                switch (choice) {
                    case 1:
                        System.out.println("Enter the Customer ID: ");
                        Customer customer1 = adminDao.getCustomer(Integer.parseInt(sc.nextLine()));

                        System.out.println("The Customer id is " + customer1.getUserId()
                                + " " + "Your name is " + customer1.getName()
                                + " " + "Your phone number is " + customer1.getMobNo()
                                + " " + "Your email is " + customer1.getEmail());
                        System.out.println("Your orders are ");
                        for (Order order : orderDao.getAllOrdersOfCustomer(customer1.getUserId())) {
                            System.out.println("Your order id is " + order.getOrderId()
                                    + " " + "Your total amount is " + order.getTotalPayment()
                                    + " " + "Your mode is " + order.getPaymentMode());
                        }
                        continue ADMIN;
                    case 2:
                        System.out.println("Enter the Customer ID: ");
                        int customer_id = Integer.parseInt(sc.nextLine());
                        customerDao.deleteCustomer(customer_id);
                        System.out.println("Your profile is successfully deleted. ");
                        continue ADMIN;
                    case 3:
                        Category category = createObjects.createCategory();
                        categoryDao.addCategory(category);
                        System.out.println("New Category has been successfully added with id "+category);
                        continue ADMIN;
                    case 4:
                        System.out.println("Enter the Category ID to be deleted: ");
                        int category_id=Integer.parseInt(sc.nextLine());
                        categoryDao.deleteCategory(category_id);
                        System.out.println("The Category with ID "+category_id+" has been deleted successfully");
                        continue ADMIN;
                    case 5:
                        System.out.println("Enter the Category ID: ");
                        int c_id2=Integer.parseInt(sc.nextLine());
                        System.out.println("Enter the Updated Name: ");
                        String updateCategoryName=sc.nextLine();
                        categoryDao.updateCategoryName(c_id2,updateCategoryName);
                        System.out.println("Category Name changed successfully ");
                        continue ADMIN;
                    case 6:
                        System.out.println("Enter the Category ID to get the details: ");
                        int cid3=Integer.parseInt(sc.nextLine());
                        Category category1=categoryDao.getCategoryById(cid3);
                        System.out.println(category1.getCategoryId()+" "+category1.getCategoryName());
                        continue ADMIN;
                    case 7:
                        System.out.println("The List of All Categories are ");
                        for(Category category2:categoryDao.getAllCategories())
                        {
                            System.out.println(category2.getCategoryId()+" "+category2.getCategoryName());
                        }
                        continue ADMIN;
                    case 8:
                        Product product=createObjects.createProduct();
                        productDao.addProduct(product);
                        System.out.println("The Product is successfully added. ");
                        System.out.println(product);
                        continue ADMIN;
                    case 9:
                        System.out.println("Enter the Product ID: ");
                        int pid=Integer.parseInt(sc.nextLine());
                        System.out.println("Enter the Updated Product Quantity: ");
                        int qty = Integer.parseInt(sc.nextLine());
                        productDao.updateProductQuantity(pid,qty);
                        System.out.println("The product name has been updated ");
                        continue ADMIN;
                    case 10:
                        System.out.println("Enter the Product ID:");
                        int product_id1=Integer.parseInt(sc.nextLine());
                        productDao.deleteProduct(product_id1);
                        System.out.println("The Product is successfully deleted. ");
                        continue ADMIN;
                    case 11:
                        for(Product product1:productDao.getAllProducts())
                            System.out.println(product1.getProductId()+" "+product1.getProductName()
                                    +" "+product1.getCategory().getCategoryName()
                                    +" "+product1.getPrice()
                                    +" "+product1.getQuantity() +" "+product1.getDate());
                        continue ADMIN;
                    case 12:
                        System.out.println("Enter the Product ID: ");
                        int p_id2=Integer.parseInt(sc.nextLine());
                        Product product2=productDao.getProductById(p_id2);
                        System.out.println(product2.getProductId()+" "+
                                product2.getProductName()+" "+
                                product2.getPrice()+" "+
                                product2.getQuantity());
                        continue ADMIN;

                    case 13:
                        System.out.println("Enter the Customer ID: ");
                        int c_id1=Integer.parseInt(sc.nextLine());
                        Customer customer2 = adminDao.getCustomer(c_id1);
                        System.out.println("Enter your Order ID: ");
                        int od=Integer.parseInt(sc.nextLine());
                        System.out.println("Placed order for "+customer2.getUserId()+" is ");
                        Order order = null;
                        order=orderDao.getOrderById(od);
                        System.out.println(order.getOrderId()+" "+order.getTotalPayment()+" "+order.getStatus());
                        continue ADMIN;
                    case 14:
                        System.out.println("Enter the Customer ID: ");
                        int c_id3=Integer.parseInt(sc.nextLine());
                        Customer customer3 = adminDao.getCustomer(c_id3);
                        for(Order order3:orderDao.getAllOrdersOfCustomer(customer3.getUserId()))
                        {
                            System.out.println(order3.getOrderId()+" "+order3.getStatus()+" "+order3.getTotalPayment());
                        }
                        continue ADMIN;
                    case 15:
                        System.out.println("Enter the ID of the Order you want to cancel: ");
                        int order_id = Integer.parseInt(sc.nextLine());
                        orderDao.cancelOrder(order_id);
                        System.out.println("Your order is canceled successfully ");
                        continue ADMIN;
                    case 16:
                        System.out.println("Your credentials are ");
                        System.out.println("Your Admin ID is "+ admin.getA_Id()
                                +" "+"Your name is "+admin.getA_name());
                        continue ADMIN;
                    case 17:
                        System.out.println("You are in Update Profile Section ");
                        System.out.println("Enter your Updated Name: ");
                        String newName  = sc.nextLine();
                        adminDao.updateAdminName(admin.getA_Id(), newName);
                        System.out.println("Your Name is updated successfully ");
                        continue ADMIN;
                    case 18:
                        System.out.println("Enter your Admin ID that should be deleted: ");
                        int newName1  = Integer.parseInt(sc.nextLine());
                        adminDao.deleteAdmin(newName1);
                        System.out.println("Successfully deleted. ");
                        System.exit(0);
                    case 19:
                        System.out.println("Enter the Order ID: ");
                        int order_id2 = Integer.parseInt(sc.nextLine());
                        List<Product> productList = orderDao.showOrderItems(order_id2);
                        System.out.println(productList);
                        continue ADMIN;
                    case 20:
                        System.out.println("You have been successfully logged out ");
                        System.exit(0);

                    default:
                        break ADMIN;
                }
            }
        }
    }

}
